package vistas;

import java.util.ArrayList;

import Ulilidades.Utilidades;
import dao.CategoriasDAOImpl;
import dao.ClientesDAOImpl;
import dao.ProductosDAOImpl;
import dao.ProveedoresDAOImpl;
import modelosPOJO.Categoria;
import modelosPOJO.Cliente;
import modelosPOJO.Producto;
import modelosPOJO.Proveedor;
/**
 * 
 * Interfaz del programa
 * @author pedro Barrero
 * @since 25/05/2026
 * @version 1.0
 *
 */
public class InterfazConsola {
	//Utilidades
	Utilidades util = new Utilidades();
	//DAO
	CategoriasDAOImpl cat = new CategoriasDAOImpl();
	ClientesDAOImpl cli = new ClientesDAOImpl();
	ProductosDAOImpl pro = new ProductosDAOImpl();
	ProveedoresDAOImpl prov = new ProveedoresDAOImpl();
	
	//Mostrar listas
	/**
	 * Mostrar la lista de categorías
	 * @param listaCategorias la lista con los objetos Categoria añadidos
	 */
	public void mostrarListaCategorias(ArrayList<Categoria> listaCategorias) {
		if(listaCategorias == null || listaCategorias.isEmpty()) {
			System.out.println("\nNo hay categorias que mostrar");
			return;
			}
			System.out.println("\n-- LISTA DE CATEGORIAS --");
			System.out.printf("%-5s %-10s\n", "ID", "NOMBRE");
			
			for(Categoria c : listaCategorias) {
				System.out.printf("%-5s %-10s\n", c.getCategoria_id(), c.getNombre());
			}
			System.out.println("----------------------------------------------------------------------------");
	}
	/**
	 * Mostrar la lista de clientes
	 * @param listaClientes la lista con los objetos Cliente añadidos
	 */
    public void mostrarListaClientes(ArrayList<Cliente> listaClientes) {
    	if(listaClientes == null || listaClientes.isEmpty()) {
			System.out.println("\nNo hay clientes que mostrar");
			return;
			}
			System.out.println("\n-- LISTA DE CLIENTES --");
			System.out.printf("%-5s %-15s %-25s %-20s\n", "ID", "NOMBRE", "CORREO", "CONTRASEÑA");
			
			for(Cliente c : listaClientes) {
				System.out.printf("%-5s %-15s %-25s %-20s\n", c.getId_cliente(), c.getNombre(), c.getCorreo(), c.getContraseña());
			}
			System.out.println("----------------------------------------------------------------------------");
	}
	/**
	 * Mostrar la lista de productos
	 * @param listaProductos la lista con los objetos Producto añadidos
	 */
	public void mostrarListaProductos(ArrayList<Producto> listaProductos) {
		if(listaProductos == null || listaProductos.isEmpty()) {
			System.out.println("\nNo hay productos que mostrar");
			return;
			}
			System.out.println("\n-- LISTA DE PRODUCTOS --");
			System.out.printf("%-5s %-30s %-20s %-20s %-20s\n", "ID", "NOMBRE", "PRECIO", "CATEGORÍA_ID", "PROVEEDOR_ID");
			
			for(Producto p : listaProductos) {
				System.out.printf("%-5s %-30s %-20s %-20s %-20s\n", p.getId_producto(), p.getNombre(), p.getPrecio(), p.getId_categoria(), p.getId_proveedor());
			}
			System.out.println("----------------------------------------------------------------------------");
	}
	/**
	 * Mostrar la lista de proveedores
	 * @param listaProveedores la lista con los objetos Proveedor añadidos
	 */
	public void mostrarProveedores(ArrayList<Proveedor> listaProveedores) {
		if(listaProveedores == null || listaProveedores.isEmpty()) {
			System.out.println("\nNo hay proveedores que mostrar");
			return;
			}
			System.out.println("\n-- LISTA DE PROVEEDORES --");
			System.out.printf("%-5s %-15s %-15s\n", "ID", "NOMBRE", "CONTACTO");
			
			for(Proveedor pr : listaProveedores) {
				System.out.printf("%-5s %-15s %-15s\n", pr.getId_proveedor(), pr.getNombre(), pr.getContacto());
			}
			System.out.println("----------------------------------------------------------------------------");
	}
	
	/**
	 * Apartado visual con las opciones del menú
	 */
	public void mostrarMenu() {
		System.out.println("\n ----- MENÚ ----- ");
		System.out.println("\n  1. Productos");
		System.out.println("  2. Clientes");
		System.out.println("  3. Proveedores");
		System.out.println("  4. Categorias");
		System.out.println("  5. Salir");
		System.out.println("\n ----------------");
		
	}
	/**
	 * Distintas opciones para Cliente
	 */
	public void opcionesClientes() {
		System.out.println("\n\n[ OPCIONES CLIENTES ]");
		System.out.println("1. Consultar clientes");
		System.out.println("2. Modificar cliente");
		System.out.println("3. Añadir cliente");
		System.out.println("4. Eliminar cliente");
		System.out.println("5. Volver al menú");
	}
	/**
	 * Distintas opciones para Producto
	 */
	public void opcionesProductos() {
		System.out.println("\n\n[ OPCIONES PRODUCTOS ]");
		System.out.println("1. Consultar productos");
		System.out.println("2. Modificar producto");
		System.out.println("3. Añadir producto");
		System.out.println("4. Eliminar producto");
		System.out.println("5. Volver al menú");
	}
	/**
	 * Distintas opciones para Proveedor
	 */
	public void opcionesProveedores() {
		System.out.println("\n\n[ OPCIONES PROVEEDORES ]");
		System.out.println("1. Consultar proveedores");
		System.out.println("2. Modificar proveedor");
		System.out.println("3. Añadir proveedor");
		System.out.println("4. Eliminar proveedor");
		System.out.println("5. Volver al menú");
	}
	/**
	 * Distintas opciones para Categoría
	 */
	public void opcionesCategorias() {
		System.out.println("\n\n[ OPCIONES CATEGORIAS ]");
		System.out.println("1. Consultar categorias");
		System.out.println("2. Modificar categoría");
		System.out.println("3. Añadir categoría");
		System.out.println("4. Eliminar categoría");
		System.out.println("5. Volver al menú");
	}
	/**
	 * Interfaz para el loggin
	 */
	public void inicioSesion() {
		System.out.println("================");
		System.out.println("INICIO DE SESIÓN");
		System.out.println("================");
	}
}
