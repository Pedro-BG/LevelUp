package modelosPOJO;
/**
 * 
 * Modelo de Proveedor
 * @author pedro Barrero
 * @since 21/05/2026
 * @version 1.0
 *
 */
public class Proveedor {
	/**
	 * Atributos id, nombre y contacto
	 */
	private int id_proveedor;
	private String nombre;
	private String contacto;
	/**
	 * Constructor de Proveedor
	 * @param id_proveedor
	 * @param nombre
	 * @param contacto
	 */
	public Proveedor(int id_proveedor, String nombre, String contacto) {
		super();
		this.id_proveedor = id_proveedor;
		this.nombre = nombre;
		this.contacto = contacto;
	}
	/**
	 * Getter del id
	 * @return id
	 */
	public int getId_proveedor() {
		return id_proveedor;
	}
	/**
	 * Setter del id
	 * @param id_proveedor nuevo id
	 */
	public void setId_proveedor(int id_proveedor) {
		this.id_proveedor = id_proveedor;
	}
	/**
	 * Getter del nombre
	 * @return nombre
	 */
	public String getNombre() {
		return nombre;
	}
	/**
	 * Setter del nombre
	 * @param nombre nuevo nombre
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	/**
	 * Getter del contacto
	 * @return contacto
	 */
	public String getContacto() {
		return contacto;
	}
	/**
	 * Setter del contacto
	 * @param contacto nuevo contacto
	 */
	public void setContacto(String contacto) {
		this.contacto = contacto;
	}
	/**
	 * Método toString de la clase Proveedor
	 */
	@Override
	public String toString() {
		return "ID = " + id_proveedor + ", Nombre = " + nombre + ", Contacto = " + contacto;
	}
	
}
