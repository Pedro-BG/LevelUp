package modelosPOJO;
/**
 * 
 * Modelo de Cliente
 * @author pedro Barrero
 * @since 21/05/2026
 * @version 1.0
 *
 */
public class Cliente {
	/**
	 * Atributos de id, nombre, correo y contraseña del cliente
	 */
	private int id_cliente;
	private String nombre;
	private String correo;
	private String contraseña;
	/**
	 * Constructor de la clase Cliente
	 * @param id_cliente id del cliente
	 * @param nombre del cliente
	 * @param correo del cliente
	 * @param contraseña del cliente
	 */
	public Cliente(int id_cliente, String nombre, String correo, String contraseña) {
		super();
		this.id_cliente = id_cliente;
		this.nombre = nombre;
		this.correo = correo;
		this.contraseña = contraseña;
	}
	/**
	 * Getter del id
	 * @return id del cliente
	 */
	public int getId_cliente() {
		return id_cliente;
	}
	/**
	 * Setter del id
	 * @param id_cliente nuevo id
	 */
	public void setId_cliente(int id_cliente) {
		this.id_cliente = id_cliente;
	}
	/**
	 * Getter del nombre
	 * @return nombre
	 */
	public String getNombre() {
		return nombre;
	}
	/**
	 * Setter del nombre
	 * @param nombre nuevo nombre
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	/**
	 * Getter del correo
	 * @return correo
	 */
	public String getCorreo() {
		return correo;
	}
	/**
	 * Setter del correo
	 * @param correo nuevo correo
	 */
	public void setCorreo(String correo) {
		this.correo = correo;
	}
	/**
	 * Getter de la contraseña
	 * @return contraseña
	 */
	public String getContraseña() {
		return contraseña;
	}
	/**
	 * Setter de la contraseña
	 * @param contraseña nueva contraseña
	 */
	public void setContraseña(String contraseña) {
		this.contraseña = contraseña;
	}
	/**
	 * Método toString para la clase Cliente
	 */
	@Override
	public String toString() {
		return "ID = " + id_cliente + ", Nombre = " + nombre + ", Correo = " + correo + ", Contraseña = "
				+ contraseña;
	}
}
