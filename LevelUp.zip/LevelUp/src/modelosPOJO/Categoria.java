package modelosPOJO;
/**
 * 
 * Modelo de Categoría
 * @author pedro Barrero
 * @since 21/05/2026
 * @version 1.0
 *
 */
public class Categoria {
	/**
	 * Parámetros del id de la categoría y su nombre
	 */
	private int categoria_id;
	private String nombre;
	/**
	 * Constructor para categorias
	 * @param categoria_id parámetro de id
	 * @param nombre parámetro de nombre
	 */
	public Categoria(int categoria_id, String nombre) {
		super();
		this.categoria_id = categoria_id;
		this.nombre = nombre;
	}
	/**
	 * Getter del id
	 * @return el id
	 */
	public int getCategoria_id() {
		return categoria_id;
	}
	/**
	 * Setter del id
	 * @param categoria_id nuevo id
	 */
	public void setCategoria_id(int categoria_id) {
		this.categoria_id = categoria_id;
	}
	/**
	 * Getter del nombre
	 * @return el nombre
	 */
	public String getNombre() {
		return nombre;
	}
	/**
	 * Setter del nombre
	 * @param nombre nuevo nombre
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	/**
	 * Método toString de categoría
	 */
	@Override
	public String toString() {
		return "ID = " + categoria_id + ", Nombre = " + nombre;
	}
	
}
