package modelosPOJO;
/**
 * 
 * Modelo de Producto
 * @author pedro Barrero
 * @since 21/05/2026
 * @version 1.0
 *
 */
public class Producto {
	/**
	 * Atributos id, nombre, precio, id de la categoría e id del proveedor
	 */
	private int id_producto;
	private String nombre;
	private double precio;
	private int id_categoria;
	private int id_proveedor;
	/**
	 * Constructor de la clase Producto
	 * @param id_producto
	 * @param nombre
	 * @param precio
	 * @param id_categoria
	 * @param id_proveedor
	 */
	public Producto(int id_producto, String nombre, double precio, int id_categoria, int id_proveedor) {
		super();
		this.id_producto = id_producto;
		this.nombre = nombre;
		this.precio = precio;
		this.id_categoria = id_categoria;
		this.id_proveedor = id_proveedor;
	}
	/**
	 * Getter del id
	 * @return id
	 */
	public int getId_producto() {
		return id_producto;
	}
	/**
	 * Setter del id
	 * @param id_producto nuevo id
	 */
	public void setId_producto(int id_producto) {
		this.id_producto = id_producto;
	}
	/**
	 * Getter del nombre
	 * @return nombre
	 */
	public String getNombre() {
		return nombre;
	}
	/**
	 * Setter del nombre
	 * @param nombre nuevo
	 */
	public void setNombre(String nombre) {
		this.nombre = nombre;
	}
	/**
	 * Getter del precio
	 * @return precio
	 */
	public double getPrecio() {
		return precio;
	}
	/**
	 * Setter del precio
	 * @param precio nuevo precio
	 */
	public void setPrecio(double precio) {
		this.precio = precio;
	}
	/**
	 * Getter del id de la categoría
	 * @return id categoría
	 */
	public int getId_categoria() {
		return id_categoria;
	}
	/**
	 * Setter del id de la categoría
	 * @param id_categoria nuevo id categoría
	 */
	public void setId_categoria(int id_categoria) {
		this.id_categoria = id_categoria;
	}
	/**
	 * Getter del id del proveedor
	 * @return id proveedor
	 */
	public int getId_proveedor() {
		return id_proveedor;
	}
	/**
	 * Setter del id del proveedor
	 * @param id_proveedor nuevo id de proveedor
	 */
	public void setId_proveedor(int id_proveedor) {
		this.id_proveedor = id_proveedor;
	}
	/**
	 * Método toString para la clase Producto
	 */
	@Override
	public String toString() {
		return "ID = " + id_producto + ", Nombre = " + nombre + ", Precio = " + precio + ", Categoria ID = "
				+ id_categoria + ", Proveedor ID = " + id_proveedor;
	}
}
