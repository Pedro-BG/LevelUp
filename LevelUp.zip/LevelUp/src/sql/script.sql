CREATE DATABASE levelup;
USE levelup;

-- Estructura de tablas
CREATE TABLE Usuario(
	id_usuario INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(50) NOT NULL,
    contraseña VARCHAR(50) NOT NULL,
    administrador BOOLEAN NOT NULL
);

CREATE TABLE Proveedor(
	id_proveedor INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(50) NOT NULL,
    contacto VARCHAR(50) NOT NULL
);

CREATE TABLE Categoria(
	id_categoria INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(50) NOT NULL
);

CREATE TABLE Producto(
	id_producto INT PRIMARY KEY AUTO_INCREMENT,
    nombre VARCHAR(50) NOT NULL,
    precio DOUBLE NOT NULL,
    id_categoria INT NOT NULL,
    id_proveedor INT NOT NULL,
    FOREIGN KEY (id_categoria) REFERENCES Categoria (id_categoria),
    FOREIGN KEY (id_proveedor) REFERENCES Proveedor (id_proveedor)
);
    
    CREATE TABLE Cliente(
		id_cliente INT PRIMARY KEY AUTO_INCREMENT,
        nombre VARCHAR(50),
        correo VARCHAR(50) UNIQUE,
        contraseña VARCHAR (50)
    );
    
    CREATE TABLE Pedido(
		id_pedido INT PRIMARY KEY AUTO_INCREMENT,
        id_cliente INT NOT NULL
    );
	
    CREATE TABLE LineaProducto(
		id_lineaProducto INT PRIMARY KEY AUTO_INCREMENT,
        id_producto INT NOT NULL,
        cantidad INT NOT NULL,
        precio DOUBLE NOT NULL,
        FOREIGN KEY (id_producto) REFERENCES Producto (id_producto)
    );