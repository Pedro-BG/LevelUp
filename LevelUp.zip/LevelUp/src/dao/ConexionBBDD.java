package dao;
import java.sql.Connection;
import java.sql.DriverManager;

import config.LeerUsuario;
/**
 * 
 * Clase para conexión a la base de datos
 * @author pedro Barrero
 * @since 21/05/2026
 * @version 1.0
 *
 */
public class ConexionBBDD {
	//Atributo para la coneción
	private Connection conn;
	//Constructor con coneción a la BBDD
	public ConexionBBDD() {
		super();
	}
	
	public Connection Conexion() {
		try {
			
			Class.forName("com.mysql.cj.jdbc.Driver");
			String usr = LeerUsuario.getDBUser();
			String pwd = LeerUsuario.getDBPassword();
			String url = LeerUsuario.getDBUrl();
			conn = DriverManager.getConnection(url, usr, pwd);
			
		}catch(Exception e){
			System.out.println("Conexión con la BBDD fallida");
			e.printStackTrace();
			return null;
		}
		return conn;
	}
	
}
