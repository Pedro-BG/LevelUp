package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;

import Ulilidades.Utilidades;
import log.Log;

public class UsuarioPruebaDAO {
	// Conexión a la base de datos
		ConexionBBDD conn = new ConexionBBDD();
		Connection conexion = conn.Conexion();
	// Utilidades
		Utilidades util = new Utilidades();
		
	/**
	 * Función para añadir usuarios nuevos para hacer pruebas de login
	 */
	public void añadirUsuario(String nombre, String contraseña, boolean administrador) {
		try {
			//Cifrado de contraseña
			String contraseñaCifrada = util.hash(contraseña);
			// Consulta preparada
			String insertar = "INSERT INTO Usuario (nombre,contraseña,administrador) VALUES (?,?,?)";
			PreparedStatement stmt = conexion.prepareStatement(insertar);
			stmt.setString(1, nombre);
			stmt.setString(2, contraseñaCifrada);
			stmt.setBoolean(3, administrador);
			// Ejecutar consulta
			stmt.executeUpdate();
			Log.registrar("Cliente añadido");
		} catch (Exception e) {
			System.out.println("==========================");
			System.out.println("ERROR al añadir el usuario");
			System.out.println("==========================");
			e.printStackTrace();
			Log.registrar("Error al añadir cliente");
		}
	}
}
