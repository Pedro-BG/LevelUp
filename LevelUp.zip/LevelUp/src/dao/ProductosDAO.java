package dao;
import java.util.ArrayList;
import modelosPOJO.Producto;
/**
 * 
 * Métodos CRUD de Productos
 * @author pedro Barrero
 * @since 21/05/2026
 * @version 1.0
 *
 */
public interface ProductosDAO {
	//Consultar categorias
	public ArrayList<Producto> consultaProductos();
	//Insertar categorias
	public void añadirProducto(String nombre, double precio, int id_categoria, int id_proveedor);
	//Eliminar categorias
	public void eliminarProducto(int id);
	//Actualizar categoria
	public void actualizarProducto();
}
