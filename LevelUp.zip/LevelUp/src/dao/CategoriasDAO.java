package dao;
import java.util.ArrayList;
import modelosPOJO.Categoria;
/**
 * 
 * Métodos CRUD de Categorías
 * @author pedro Barrero
 * @since 21/05/2026
 * @version 1.0
 *
 */
public interface CategoriasDAO {
	//Consultar categorias
	public ArrayList<Categoria> consultaCategorias();
	//Insertar categorias
	public void añadirCategoria(String nombre);
	//Eliminar categorias
	public void eliminarCategoria(int id);
	//Actualizar categoria
	public void actualizarCategoria();
}
