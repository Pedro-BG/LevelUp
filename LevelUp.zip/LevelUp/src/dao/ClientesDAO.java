package dao;
import java.util.ArrayList;
import modelosPOJO.Cliente;
/**
 * 
 * Métodos CRUD de Clientes
 * @author pedro Barrero
 * @since 21/05/2026
 * @version 1.0
 *
 */
public interface ClientesDAO {
	//Consultar categorias
	public ArrayList<Cliente> consultaClientes();
	//Insertar categorias
	public void añadirCliente(String nombre, String correo, String contraseña);
	//Eliminar categorias
	public void eliminarCliente(int id);
	//Actualizar categoria
	public void actualizarCliente();
}
