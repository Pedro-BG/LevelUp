package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import Ulilidades.Utilidades;
import modelosPOJO.Cliente;

/**
 * 
 * Implementación de las funciones del DAO Clientes
 * @author pedro Barrero
 * @since 22/05/2026
 * @version 1.0
 *
 */
public class ClientesDAOImpl implements ClientesDAO{
	// Utilidades
	Utilidades util = new Utilidades();
	// Conexión a la base de datos
	ConexionBBDD conn = new ConexionBBDD();

	Connection conexion = conn.Conexion();
	
	/**
	 * Función para consultar los clientes
	 */
	@Override
	public ArrayList<Cliente> consultaClientes() {
		ArrayList<Cliente> listadoClientes = new ArrayList<Cliente>();
		try {
			Statement st = conexion.createStatement();
			ResultSet rs;
			// Consulta preparada
			String consulta = "SELECT * FROM Cliente";
			rs = st.executeQuery(consulta);
			// Obtener los campos
			while (rs.next()) {
				int id = rs.getInt("id_cliente");
				String nombre = rs.getString("nombre");
				String correo = rs.getString("correo");
				String contraseña = rs.getString("contraseña");
				// Crear un objeto Cliente con los campos
				Cliente cli = new Cliente(id, nombre, correo, contraseña);
				// Añadir el objeto a la lista
				listadoClientes.add(cli);
			}
		} catch (Exception e) {
			System.out.println("=============================");
			System.out.println("ERROR AL MOSTRAR LOS CLIENTES");
			System.out.println("=============================");
			e.printStackTrace();
		}
		return listadoClientes;
	}

	//
	// Si hay objetos creados con el foreign key del id_categoria no se puede
	// eliminar
	//
	/**
	 * Función para eliminar un cliente mediante su ID
	 */
	@Override
	public void eliminarCliente(int id) {
		try {
			// Consulta preparada
			String eliminar = "DELETE FROM Cliente WHERE id_cliente = ?";
			PreparedStatement stmt = conexion.prepareStatement(eliminar);
			stmt.setInt(1, id);
			// Ejecutar consulta
			stmt.executeUpdate();
			System.out.println("-- Cliente eliminado correctamente --");
		} catch (Exception e) {
			System.out.println("===========================");
			System.out.println("ERROR al eliminar categoría");
			System.out.println("===========================");
			
		}
	}
	
	/**
	 * Función para actualizar elementos de un cliente
	 */
	@Override
	public void actualizarCliente() {
		int id = util.leerEntero("ID del cliente a modificar");
		try {
			String consulta = "SELECT * FROM Cliente WHERE id_cliente = ?";
			PreparedStatement stmt = conexion.prepareStatement(consulta);
			stmt.setInt(1, id);
			ResultSet rs = stmt.executeQuery();
			// Comprobar si existe
			if (!rs.next()) {
				System.out.println("No existe ninguna cliente con ese ID.");
				return;
			}
			// Obtener datos del cliente
			int idC1 = rs.getInt("id_cliente");
			String nombre = rs.getString("nombre");
			String correo = rs.getString("correo");
			String contraseña = rs.getString("contraseña");
			// Objeto Cliente
			Cliente cli = new Cliente(idC1, nombre, correo, contraseña);
			// Variable auxiliar para comprobar cambios
			boolean Cambios = false;
			
			//NOMBRE
			System.out.println("================================");
			System.out.println("Nombre actual: " + cli.getNombre());
			String cambioNombre = util.leerTexto("¿Quieres modificar el nombre? [ Si | No ]");
			if (cambioNombre.equalsIgnoreCase("si")) {
				String nuevoNombre = util.leerTexto("Nuevo nombre para el cliente");
				cli.setNombre(nuevoNombre);
				Cambios = true;
			}
			//CORREO
			System.out.println("================================");
			System.out.println("Correo actual: " + cli.getCorreo());
			String cambioCorreo = util.leerTexto("¿Quieres modificar el correo? [ Si | No ]");
			if (cambioCorreo.equalsIgnoreCase("si")) {
				String nuevoCorreo = util.leerTexto("Nuevo correo para el cliente");
				cli.setCorreo(nuevoCorreo);
				Cambios = true;
			}
			//CONTRASEÑA
			System.out.println("================================");
			System.out.println("Contraseña actual: " + cli.getContraseña());
			String cambioContraseña = util.leerTexto("¿Quieres modificar la contraseña? [ Si | No ]");
			if (cambioContraseña.equalsIgnoreCase("si")) {
				String nuevaContraseña = util.leerTexto("Nueva contraseña para el cliente");
				cli.setContraseña(nuevaContraseña);
				Cambios = true;
			}
			
			// Actualizar si hubo cambios
			if (Cambios) {
				String actualizar = "UPDATE Cliente SET nombre = ?, correo = ?, contraseña = ? WHERE id_cliente = ?";
				PreparedStatement stmt2 = conexion.prepareStatement(actualizar);
				stmt2.setString(1, cli.getNombre());
				stmt2.setString(2, cli.getCorreo());
				stmt2.setString(3, cli.getContraseña());
				stmt2.setInt(4, cli.getId_cliente());
				stmt2.executeUpdate();
				System.out.println("-- Actualizado correctamente --");
			} else {
				System.out.println("No se realizaron cambios.");
			}

		} catch (Exception e) {
			System.out.println("=================================");
			System.out.println("ERROR al buscar el cliente por ID");
			System.out.println("=================================");
		}
	}
	
	/**
	 * Función para añadir un Cliente nuevo
	 */
	@Override
	public void añadirCliente(String nombre, String correo, String contraseña) {
		try {
			// Consulta preparada
			String insertar = "INSERT INTO Cliente (nombre,correo,contraseña) VALUES (?,?,?)";
			PreparedStatement stmt = conexion.prepareStatement(insertar);
			stmt.setString(1, nombre);
			stmt.setString(2, correo);
			stmt.setString(3, contraseña);
			// Ejecutar consulta
			stmt.executeUpdate();
			System.out.println("-- Cliente añadido correctamente --");
		} catch (Exception e) {
			System.out.println("==========================");
			System.out.println("ERROR al añadir el cliente");
			System.out.println("==========================");
			e.printStackTrace();
		}
	}

}
