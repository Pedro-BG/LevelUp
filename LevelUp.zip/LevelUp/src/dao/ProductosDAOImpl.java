package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import Ulilidades.Utilidades;
import modelosPOJO.Producto;

/**
 * 
 * Implementación de las funciones del DAO Productos
 * @author pedro Barrero
 * @since 22/05/2026
 * @version 1.0
 *
 */
public class ProductosDAOImpl implements ProductosDAO{
	// Utilidades
	Utilidades util = new Utilidades();
	// Conexión a la base de datos
	ConexionBBDD conn = new ConexionBBDD();

	Connection conexion = conn.Conexion();
	
	/**
	 * Función para consultar los productos
	 */
	@Override
	public ArrayList<Producto> consultaProductos() {
		ArrayList<Producto> listadoProductos = new ArrayList<Producto>();
		try {
			Statement st = conexion.createStatement();
			ResultSet rs;
			// Consulta preparada
			String consulta = "SELECT * FROM Producto";
			rs = st.executeQuery(consulta);
			// Obtener los campos
			while (rs.next()) {
				int id = rs.getInt("id_producto");
				String nombre = rs.getString("nombre");
				double precio = rs.getDouble("precio");
				int id_Cat = rs.getInt("id_categoria");
				int id_Prov = rs.getInt("id_proveedor");
				// Crear un objeto Producto con los campos
				Producto pro = new Producto(id, nombre, precio, id_Cat, id_Prov);
				// Añadir el objeto a la lista
				listadoProductos.add(pro);
			}
		} catch (Exception e) {
			System.out.println("==============================");
			System.out.println("ERROR AL MOSTRAR LOS PRODUCTOS");
			System.out.println("==============================");
		}
		return listadoProductos;
	}
	
	/**
	 * Función para añadir un producto nuevo
	 */
	@Override
	public void añadirProducto(String nombre, double precio, int id_categoria, int id_proveedor) {
		try {
			// Consulta preparada
			String insertar = "INSERT INTO Producto (nombre,precio,id_categoria,id_proveedor) VALUES (?,?,?,?)";
			PreparedStatement stmt = conexion.prepareStatement(insertar);
			stmt.setString(1, nombre);
			stmt.setDouble(2, precio);
			stmt.setInt(3, id_categoria);
			stmt.setInt(4, id_proveedor);
			// Ejecutar consulta
			stmt.executeUpdate();
			System.out.println("-- Producto añadida correctamente --");
		} catch (Exception e) {
			System.out.println("===========================");
			System.out.println("ERROR al añadir el producto");
			System.out.println("===========================");
		}
	}

	/**
	 * Función para eliminar un producto mediante su ID
	 */
	@Override
	public void eliminarProducto(int id) {
		try {
			// Consulta preparada
			String eliminar = "DELETE FROM Producto WHERE id_producto = ?";
			PreparedStatement stmt = conexion.prepareStatement(eliminar);
			stmt.setInt(1, id);
			// Ejecutar consulta
			stmt.executeUpdate();
			System.out.println("-- Producto eliminado correctamente --");
		} catch (Exception e) {
			System.out.println("=============================");
			System.out.println("ERROR al eliminar el producto");
			System.out.println("=============================");
		}
	}
	
	/**
	 * Función para actualizar elementos de un producto
	 */
	@Override
	public void actualizarProducto() {
		int id = util.leerEntero("ID del producto a modificar");
	    try {
	        String consulta = "SELECT * FROM Producto WHERE id_producto = ?";
	        PreparedStatement stmt = conexion.prepareStatement(consulta);
	        stmt.setInt(1, id);
	        ResultSet rs = stmt.executeQuery();
	        // Comprobar si existe
	        if (!rs.next()) {
	            System.out.println("No existe ningun producto con ese ID.");
	            return;
	        }
	        // Obtener datos del producto
			int idC1 = rs.getInt("id_producto");
			String nombre = rs.getString("nombre");
			double precio = rs.getDouble("precio");
			int id_cat = rs.getInt("id_categoria");
			int id_pro = rs.getInt("id_proveedor");
			// Objeto Producto
			Producto pro = new Producto(idC1, nombre, precio, id_cat, id_pro);
			// Variable auxiliar para comprobar cambios
			boolean Cambios = false;

			// NOMBRE
			System.out.println("================================");
			System.out.println("Nombre actual: " + pro.getNombre());
			String cambioNombre = util.leerTexto("¿Quieres modificar el nombre? [ Si | No ]");
			if (cambioNombre.equalsIgnoreCase("si")) {
				String nuevoNombre = util.leerTexto("Nuevo nombre para el producto");
				pro.setNombre(nuevoNombre);
				Cambios = true;
			}
			// PRECIO
			System.out.println("================================");
			System.out.println("Precio actual: " + pro.getPrecio());
			String cambioPrecio = util.leerTexto("¿Quieres modificar el precio? [ Si | No ]");
			if (cambioPrecio.equalsIgnoreCase("si")) {
				double nuevoPrecio = util.leerDouble("Nuevo Precio para el producto");
				pro.setPrecio(nuevoPrecio);
				Cambios = true;
			}
			// ID DE LA CATEGORÍA
			System.out.println("================================");
			System.out.println("Categoria actual: " + pro.getId_categoria());
			String cambioIDCAT = util.leerTexto("¿Quieres modificar la categoría? [ Si | No ]");
			if (cambioIDCAT.equalsIgnoreCase("si")) {
				int nuevaIDCAT = util.leerEntero("Nuevo ID de la categoría para el producto");
				pro.setId_categoria(nuevaIDCAT);
				Cambios = true;
			}
			// ID DEL PROVEEDOR
			System.out.println("================================");
			System.out.println("Proveedor actual: " + pro.getId_proveedor());
			String cambioIDPRO = util.leerTexto("¿Quieres modificar el proveedor? [ Si | No ]");
			if (cambioIDPRO.equalsIgnoreCase("si")) {
				int nuevaIDPRO = util.leerEntero("Nuevo ID del proveedor para el producto");
				pro.setId_categoria(nuevaIDPRO);
				Cambios = true;
			}

			// Actualizar si hubo cambios
			if (Cambios) {
				String actualizar = "UPDATE Producto SET nombre = ?, precio = ?, id_categoria = ?, id_proveedor = ? WHERE id_producto = ?";
				PreparedStatement stmt2 = conexion.prepareStatement(actualizar);
				stmt2.setString(1, pro.getNombre());
				stmt2.setDouble(2, pro.getPrecio());
				stmt2.setInt(3, pro.getId_categoria());
				stmt2.setInt(4, pro.getId_proveedor());
				stmt2.setInt(5, pro.getId_producto());
				stmt2.executeUpdate();
				System.out.println("-- Actualizado correctamente --");
			} else {
				System.out.println("No se realizaron cambios.");
			}

		} catch (Exception e) {
			System.out.println("==================================");
			System.out.println("ERROR al buscar el producto por ID");
			System.out.println("==================================");
		}
	}
		
}
