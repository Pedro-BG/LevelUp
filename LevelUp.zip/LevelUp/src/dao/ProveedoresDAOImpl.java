package dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import Ulilidades.Utilidades;
import modelosPOJO.Proveedor;

/**
 * 
 * Implementación de las funciones del DAO Proveedores
 * @author pedro Barrero
 * @since 22/05/2026
 * @version 1.0
 *
 */
public class ProveedoresDAOImpl implements ProveedoresDAO{
	// Utilidades
	Utilidades util = new Utilidades();
	// Conexión a la base de datos
	ConexionBBDD conn = new ConexionBBDD();

	Connection conexion = conn.Conexion();
	
	/**
	 * Función para consultar los proveedores
	 */
	@Override
	public ArrayList<Proveedor> consultaProveedor() {
		ArrayList<Proveedor> listadoProveedores = new ArrayList<Proveedor>();
		try {
			Statement st = conexion.createStatement();
			ResultSet rs;
			// Consulta preparada
			String consulta = "SELECT * FROM Proveedor";
			rs = st.executeQuery(consulta);
			// Obtener los campos
			while (rs.next()) {
				int id = rs.getInt("id_proveedor");
				String nombre = rs.getString("nombre");
				String contacto = rs.getString("contacto");
				// Crear un objeto Proveedor con los campos
				Proveedor prov = new Proveedor(id, nombre, contacto);
				// Añadir el objeto a la lista
				listadoProveedores.add(prov);
			}
		} catch (Exception e) {
			System.out.println("================================");
			System.out.println("ERROR AL MOSTRAR LOS PROVEEDORES");
			System.out.println("================================");
		}
		return listadoProveedores;
	}
	
	/**
	 * Función para añadir un proveedor nuevo
	 */
	@Override
	public void añadirProveedor(String nombre, String contacto) {
		try {
			// Consulta preparada
			String insertar = "INSERT INTO Proveedor (nombre,contacto) VALUES (?,?)";
			PreparedStatement stmt = conexion.prepareStatement(insertar);
			stmt.setString(1, nombre);
			stmt.setString(2, contacto);
			// Ejecutar consulta
			stmt.executeUpdate();
			System.out.println("-- Proveedor añadido correctamente --");
		} catch (Exception e) {
			System.out.println("ERROR al añadir el proveedor");
			e.printStackTrace();
		}
	}
	
	/**
	 * Función para eliminar un proveedor mediante su ID
	 */
	@Override
	public void eliminarProveedor(int id)  {
		try {
			// Consulta preparada
			String eliminar = "DELETE FROM Proveedor WHERE id_proveedor = ?";
			PreparedStatement stmt = conexion.prepareStatement(eliminar);
			stmt.setInt(1, id);
			// Ejecutar consulta
			stmt.executeUpdate();
			System.out.println("-- Proveedor eliminado correctamente --");
		} catch (Exception e) {
			System.out.println("==============================");
			System.out.println("ERROR al eliminar el proveedor");
			System.out.println("==============================");
		}
	}
	
	/**
	 * Función para actualizar elementos de un proveedor
	 */
	@Override
	public void actualizarProveedor() {
		int id = util.leerEntero("ID del proveedor a modificar");
		try {
			String consulta = "SELECT * FROM Proveedor WHERE id_proveedor = ?";
			PreparedStatement stmt = conexion.prepareStatement(consulta);
			stmt.setInt(1, id);
			ResultSet rs = stmt.executeQuery();
			// Comprobar si existe
			if (!rs.next()) {
				System.out.println("No existe ningun proveedor con ese ID.");
				return;
			}
			// Obtener datos del proveedor
			int idC1 = rs.getInt("id_proveedor");
			String nombre = rs.getString("nombre");
			String contacto = rs.getString("contacto");
			// Objeto Proveedor
			Proveedor prov = new Proveedor(idC1, nombre, contacto);
			// Variable auxiliar para comprobar cambios
			boolean Cambios = false;

			// NOMBRE
			System.out.println("================================");
			System.out.println("Nombre actual: " + prov.getNombre());
			String cambioNombre = util.leerTexto("¿Quieres modificar el nombre? [ Si | No ]");
			if (cambioNombre.equalsIgnoreCase("si")) {
				String nuevoNombre = util.leerTexto("Nuevo nombre para el proveedor");
				prov.setNombre(nuevoNombre);
				Cambios = true;
			}
			// CONTACTO
			System.out.println("================================");
			System.out.println("Contacto actual: " + prov.getContacto());
			String cambioContacto = util.leerTexto("¿Quieres modificar el precio? [ Si | No ]");
			if (cambioContacto.equalsIgnoreCase("si")) {
				String nuevoContacto = util.leerTexto("Nuevo contacto para el proveedor");
				prov.setContacto(nuevoContacto);
				Cambios = true;
			}

			// Actualizar si hubo cambios
			if (Cambios) {
				String actualizar = "UPDATE Proveedor SET nombre = ?, contacto = ? WHERE id_proveedor = ?";
				PreparedStatement stmt2 = conexion.prepareStatement(actualizar);
				stmt2.setString(1, prov.getNombre());
				stmt2.setString(2, prov.getContacto());
				stmt2.setInt(3, prov.getId_proveedor());
				stmt2.executeUpdate();
				System.out.println("-- Actualizado correctamente --");
			} else {
				System.out.println("No se realizaron cambios.");
			}

		} catch (Exception e) {
			System.out.println("===================================");
			System.out.println("ERROR al buscar el proveedor por ID");
			System.out.println("===================================");
		}
	}
}
