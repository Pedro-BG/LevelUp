package dao;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;

import Ulilidades.Utilidades;
import log.Log;
import modelosPOJO.Categoria;
/**
 * 
 * Implementación de las funciones del DAO Categorías
 * @author pedro Barrero
 * @since 22/05/2026
 * @version 1.0
 *
 */
public class CategoriasDAOImpl implements CategoriasDAO{
	//Utilidades
	Utilidades util = new Utilidades();
	//Conexión a la base de datos
	ConexionBBDD conn = new ConexionBBDD();
	
	Connection conexion = conn.Conexion();
	
	/**
	 * Función para consultar las categorias
	 */
	@Override
	public ArrayList<Categoria> consultaCategorias() {
		ArrayList<Categoria> listadoCategorias = new ArrayList<Categoria>();
		try {
			Statement st = conexion.createStatement();
			ResultSet rs;
			//Consulta preparada
			String consulta = "SELECT * FROM Categoria";
			rs = st.executeQuery(consulta);
			//Obtener los campos
			while(rs.next()) {
				int id = rs.getInt("id_categoria");
				String nombre = rs.getString("nombre");
				//Crear un objeto Categoria con los campos
				Categoria cat = new Categoria(id, nombre);
				//Añadir el objeto a la lista
				listadoCategorias.add(cat);
			}
			//Registro
			Log.registrar("Consulta de Categorias realizada");
		}catch(Exception e) {
			System.out.println("===============================");
			System.out.println("ERROR AL MOSTRAR LAS CATEGORIAS");
			System.out.println("===============================");
			Log.registrar("Error al consultar las categorías");
		}		
		return listadoCategorias;
	}
	
	/**
	 * Función para eliminar una categoría mediante su ID
	 */
	@Override
	public void eliminarCategoria(int id) {
		try {
			//Consulta preparada
			String eliminar = "DELETE FROM Categoria WHERE id_categoria = ?";
			PreparedStatement stmt = conexion.prepareStatement(eliminar);
			stmt.setInt(1, id);
			//Ejecutar consulta
			stmt.executeUpdate();
			System.out.println("-- Categoría eliminada correctamente --");
			Log.registrar("Categoría eliminada");
		}catch(Exception e) {
			System.out.println("===========================");
			System.out.println("ERROR al eliminar categoría");
			System.out.println("===========================");
			Log.registrar("Error al eliminar categoría");
		}		
	}
	
	/**
	 * Función para actualizar elementos de una categoría
	 */
	@Override
	public void actualizarCategoria() {
		    int id = util.leerEntero("ID de la categoría a modificar");
		    try {
		        String consulta = "SELECT * FROM Categoria WHERE id_categoria = ?";
		        PreparedStatement stmt = conexion.prepareStatement(consulta);
		        stmt.setInt(1, id);
		        ResultSet rs = stmt.executeQuery();
		        // Comprobar si existe
		        if (!rs.next()) {
		            System.out.println("No existe ninguna categoría con ese ID.");
		            return;
		        }
		        // Obtener datos de la categoria 
		        int idC1 = rs.getInt("id_categoria");
		        String nombre = rs.getString("nombre");
		        //Objeto categoria
		        Categoria cat = new Categoria(idC1, nombre);
		        System.out.println("================================");
		        System.out.println("Categoría actual: " + cat.getNombre());
		        String cambioNombre = util.leerTexto("¿Quieres modificar el nombre? [ Si | No ]");
		        //Variable auxiliar para comprobar cambios
		        boolean Cambios = false;
		        if (cambioNombre.equalsIgnoreCase("si")) {
		            String nuevoNombre = util.leerTexto("Nuevo nombre para la categoría");
		            cat.setNombre(nuevoNombre);
		            Cambios = true;
		        }
		        //Actualizar si hubo cambios
		        if (Cambios) {
		            String actualizar = "UPDATE Categoria SET nombre = ? WHERE id_categoria = ?";
		            PreparedStatement stmt2 = conexion.prepareStatement(actualizar);
		            stmt2.setString(1, cat.getNombre());
		            stmt2.setInt(2, cat.getCategoria_id());
		            stmt2.executeUpdate();
		            System.out.println("-- Actualizado correctamente --");
		            Log.registrar("Categoría actualizada");
		        } else {
		            System.out.println("No se realizaron cambios.");
		        }

		    } catch (Exception e) {
		    	System.out.println("===================================");
		        System.out.println("ERROR al buscar la categoría por ID");
		        System.out.println("===================================");
		        Log.registrar("Error al actualizar categoría");
		    }
		}

	/**
	 * Función para añadir una categoría nueva
	 */
	@Override
	public void añadirCategoria(String nombre) {
		try {
			//Consulta preparada
			String insertar = "INSERT INTO Categoria (nombre) VALUES (?)";
			PreparedStatement stmt = conexion.prepareStatement(insertar);
			stmt.setString(1, nombre);
			//Ejecutar consulta
			stmt.executeUpdate();
			System.out.println("-- Categoría añadida correctamente --");
			Log.registrar("Categoría añadida");
		}catch(Exception e) {
			System.out.println("=========================");
			System.out.println("ERROR al añadir categoría");
			System.out.println("=========================");
			Log.registrar("Error al añadir categoría");
		}
	}
	
	/**
	 * Función para comprobar si existe una categoría y ver su id
	 * @param categoria a buscar
	 */
	public void comprobarCategoria(String categoria) {
		try {
			Statement st = conexion.createStatement();
			ResultSet rs;
			//Consulta preparada
			String consulta = "SELECT * FROM Categoria";
			rs = st.executeQuery(consulta);
			while(rs.next()) {
				int id = rs.getInt("id_categoria");
				String nombre = rs.getString("nombre");
				if(nombre.equalsIgnoreCase(categoria)) {
					System.out.println("El ID correspondiente a "+ categoria +" es: "+ id);
					return;
				}
			}
			System.out.println("No hay ninguna categoría "+ categoria + " creada");
			Log.registrar("ID de categoría consultado");
		} catch (Exception e) {
			System.out.println("======================================");
			System.out.println("ERROR al buscar el ID de esa categoría");
			System.out.println("======================================");
			Log.registrar("Error al consultar el id de una categoría");
		}
	}

}
