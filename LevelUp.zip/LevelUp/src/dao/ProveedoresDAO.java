package dao;
import java.util.ArrayList;
import modelosPOJO.Proveedor;
/**
 * 
 * Métodos CRUD de Proveedores
 * @author pedro Barrero
 * @since 21/05/2026
 * @version 1.0
 *
 */
public interface ProveedoresDAO {
	//Consultar categorias
	public ArrayList<Proveedor> consultaProveedor();
	//Insertar categorias
	public void añadirProveedor(String nombre, String contacto);
	//Eliminar categorias
	public void eliminarProveedor(int id);
	//Actualizar categoria
	public void actualizarProveedor();
}
