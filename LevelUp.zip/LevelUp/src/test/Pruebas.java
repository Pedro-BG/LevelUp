package test;

import static org.junit.jupiter.api.Assertions.*;

import java.util.ArrayList;
import org.junit.jupiter.api.Test;
import dao.ProductosDAOImpl;
import modelosPOJO.Producto;

/**
 * Clase de ejemplos de pruebas unitarias
 * @author Pedro
 * @version 1.0
 * @since 27/05/2026
 */
public class Pruebas {
	ProductosDAOImpl pro = new ProductosDAOImpl();
	
	//PRUEBAS PARA CONSTRUCTORES, GETTERS Y SETTERS
	/**
	 * Prueba del constructor y getters
	 */
	@Test
	void testConstructorYGetters() {
		Producto p = new Producto(1, "Teclado", 25.50, 2, 3);
		assertEquals(1, p.getId_producto());
		assertEquals("Teclado", p.getNombre());
		assertEquals(25.50, p.getPrecio());
		assertEquals(2, p.getId_categoria());
		assertEquals(3, p.getId_proveedor());
	}
	/**
	 * Prueba de setters
	 */
	@Test
	void testSetters() {
		Producto p = new Producto(1, "Teclado", 25.50, 2, 3);
		p.setId_producto(10);
		p.setNombre("Ratón");
		p.setPrecio(15.99);
		p.setId_categoria(5);
		p.setId_proveedor(8);
		assertEquals(10, p.getId_producto());
		assertEquals("Ratón", p.getNombre());
		assertEquals(15.99, p.getPrecio());
		assertEquals(5, p.getId_categoria());
		assertEquals(8, p.getId_proveedor());
	}

	/**
	 * Prueba del método toString
	 */
	@Test
	void testToString() {
		Producto p = new Producto(1, "Teclado", 25.50, 2, 3);
		String esperado = "ID = 1, Nombre = Teclado, Precio = 25.5, Categoria ID = 2, Proveedor ID = 3";
		assertEquals(esperado, p.toString());
	}
	
    // ============================================================
    //  PRUEBAS DE CONSULTA
    // ============================================================
    @Test
    public void testConsultaProductosNoEsNull() {
        ArrayList<Producto> lista = pro.consultaProductos();
        assertNotNull(lista, "La lista de productos no debe ser null");
    }
    @Test
    public void testConsultaProductosDevuelveLista() {
        ArrayList<Producto> lista = pro.consultaProductos();
        assertTrue(lista.size() >= 0, "La consulta debe devolver una lista válida");
    }
    // ============================================================
    //  PRUEBAS DE INSERCIÓN
    // ============================================================
    @Test
    public void testAñadirProductoYVerificarInsercion() {
        String nombre = "JUnit_Insert";
        double precio = 10.50;
        int idCategoria = 1;
        int idProveedor = 1;

        pro.añadirProducto(nombre, precio, idCategoria, idProveedor);

        ArrayList<Producto> lista = pro.consultaProductos();
        boolean encontrado = lista.stream()
                .anyMatch(p -> p.getNombre().equals(nombre) && p.getPrecio() == precio);

        assertTrue(encontrado, "El producto insertado debe aparecer en la base de datos");
    }
    // ============================================================
    //  PRUEBAS DE ELIMINACIÓN
    // ============================================================
    @Test
    public void testEliminarProductoNoLanzaExcepcion() {
        assertDoesNotThrow(() -> pro.eliminarProducto(999999),
                "Eliminar un ID inexistente no debe lanzar excepción");
    }
    @Test
    public void testAñadirYEliminarProducto() {
        String nombre = "JUnit_Delete";
        double precio = 5.99;
        int idCategoria = 1;
        int idProveedor = 1;

        // Insertar
        pro.añadirProducto(nombre, precio, idCategoria, idProveedor);

        // Buscar el producto insertado
        ArrayList<Producto> lista = pro.consultaProductos();
        Producto insertado = lista.stream()
                .filter(p -> p.getNombre().equals(nombre))
                .reduce((first, second) -> second)
                .orElse(null);

        assertNotNull(insertado, "El producto debería existir antes de eliminarlo");

        // Eliminar
        pro.eliminarProducto(insertado.getId_producto());

        // Verificar eliminación
        ArrayList<Producto> listaDespues = pro.consultaProductos();
        boolean sigueExistiendo = listaDespues.stream()
                .anyMatch(p -> p.getId_producto() == insertado.getId_producto());
    }
}
