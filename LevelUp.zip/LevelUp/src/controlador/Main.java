package controlador;

import java.util.ArrayList;

import Ulilidades.Utilidades;
import dao.CategoriasDAOImpl;
import dao.ClientesDAOImpl;
import dao.ProductosDAOImpl;
import dao.ProveedoresDAOImpl;
import modelosPOJO.Categoria;
import modelosPOJO.Cliente;
import modelosPOJO.Producto;
import modelosPOJO.Proveedor;
import vistas.InterfazConsola;
/**
 * 
 * Controlador y parte principal de la aplicación
 * @author pedro Barrero
 * @since 25/05/2026
 * @version 1.0
 *
 */
public class Main {
	public static void main(String[] args) {
		//Vista
		InterfazConsola vista = new InterfazConsola();
		
		//Utilidades
		Utilidades util = new Utilidades();
		
		//DAOs
		CategoriasDAOImpl cat = new CategoriasDAOImpl();
		ClientesDAOImpl cli = new ClientesDAOImpl();
		ProductosDAOImpl pro = new ProductosDAOImpl();
		ProveedoresDAOImpl prov = new ProveedoresDAOImpl();
		
		/**
		 * Parte principal
		 */
		int opcion = 0;
		System.out.println("================================");
		System.out.println("LevelUP --> Gestor de inventario");
		System.out.println("================================");
		do {
			//Menú
			vista.mostrarMenu();
			opcion = util.leerEntero("Elige un apartado");
			/**
			 * Distintos apartados dentro del menú
			 */
			switch(opcion) {
				/**
				 * Productos
				 */
				case 1:
					//Opciones Productos
					int opcion2 = 0;
					do {
						//Lista para productos
						ArrayList<Producto> listaProducto = pro.consultaProductos();
						vista.opcionesProductos();
						opcion2 = util.leerEntero("\nElige una opción");
						/**
						 * CRUD de productos
						 */
						switch(opcion2) {
							case 1:
								vista.mostrarListaProductos(listaProducto);;
								break;
							case 2:
								pro.actualizarProducto();
								break;
							case 3:
								String nombre = util.leerTexto("Nombre del Producto");
								double precio = util.leerDouble("Precio del producto");
								int id_cat = util.leerEntero("ID de la categoría");
								int id_prov = util.leerEntero("ID del proveedor");
								pro.añadirProducto(nombre, precio, id_cat, id_prov);
								break;
							case 4:
								int id = util.leerEntero("ID del producto a eliminar");
								pro.eliminarProducto(id);
								break;
							case 5:
								System.out.println("");
								break;
						}
					}while(opcion2 != 5);
					break;
				/**
				 * Clientes
				 */
				case 2:
					//Opciones Clientes
					int opcion3 = 0;
					do {
						//Lista para clientes
						ArrayList<Cliente> listaClientes = cli.consultaClientes();
						vista.opcionesClientes();
						opcion3 = util.leerEntero("\nElige una opción");
						/**
						 * CRUD de clientes
						 */
						switch(opcion3) {
							case 1:
								vista.mostrarListaClientes(listaClientes);
								break;
							case 2:
								cli.actualizarCliente();
								break;
							case 3:
								String nombre = util.leerTexto("Nombre del cliente");
								String correo = util.leerTexto("Correo del cliente");
								String contraseña = util.leerTexto("Contraseña del cliente");
								cli.añadirCliente(nombre, correo, contraseña);
								break;
							case 4:
								int id = util.leerEntero("ID del cliente a eliminar");
								cli.eliminarCliente(id);
								break;
							case 5:
								System.out.println("");
								break;
						}
					}while(opcion3 != 5);
					break;
				/**
				 * Proveedor
				 */
				case 3:
					//Opciones Proveedores
					int opcion4 = 0;
					do {
						//Lista para proveedores
						ArrayList<Proveedor> listaProveedor = prov.consultaProveedor();
						vista.opcionesProveedores();
						opcion4 = util.leerEntero("\nElige una opción");
						/**
						 * CRUD de proveedores
						 */
						switch(opcion4) {
							case 1:
								vista.mostrarProveedores(listaProveedor);
								break;
							case 2:
								prov.actualizarProveedor();
								break;
							case 3:
								String nombre = util.leerTexto("Nombre del Proveedor");
								String contacto = util.leerTexto("Contacto del proveedor");
								prov.añadirProveedor(nombre, contacto);
								break;
							case 4:
								int id = util.leerEntero("ID del proveedor a eliminar");
								prov.eliminarProveedor(id);
								break;
							case 5:
								System.out.println("");
								break;
						}
					}while(opcion4 != 5);
					break;
				/**
				 * Categoria
				 */
				case 4:
					//Opciones Categorias
					int opcion5 = 0;
					do {
						//Lista para Categorias
						ArrayList<Categoria> listaCategorias = cat.consultaCategorias();
						vista.opcionesCategorias();
						opcion5 = util.leerEntero("\nElige una opción");
						/**
						 * CRUD de categorias
						 */
						switch(opcion5) {
							case 1:
								vista.mostrarListaCategorias(listaCategorias);
								break;
							case 2:
								cat.actualizarCategoria();
								break;
							case 3:
								String nombre = util.leerTexto("Nombre de la nueva categoría");
								cat.añadirCategoria(nombre);
								break;
							case 4:
								int id = util.leerEntero("ID de la categoría a eliminar");
								cat.eliminarCategoria(id);
								break;
							case 5:
								System.out.println("");
								break;
						}
					}while(opcion5 != 5);
					break;
				/**
				 * Fin del programa
				 */
				case 5:
					System.out.printf("\n%10s", "===");
					System.out.printf("\n%10s", "FIN");
					System.out.printf("\n%10s", "===");
					break;
			}
		}while(opcion != 5);
	}
}
