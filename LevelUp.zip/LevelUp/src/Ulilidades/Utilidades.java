package Ulilidades;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Scanner;

/**
 * Clase Utilidades
 * 
 * @author Victor Colomo
 * 
 * Esta clase contiene métodos para la lectura de datos por teclado
 * Cada instancia de Utilidades gestiona su propio objeto Scanner, lo que
 * permite independecia entre los distintos procesos que usen la clase
 * 
 */
public class Utilidades {

	/** Scanner para la lectura de datos desde consola */
    private final Scanner sc;

    /**
     * Constructor por defecto
     * Inicializa el Scanner para leer desde la entrada estándar (System.in)
     */
    public Utilidades() {
        sc = new Scanner(System.in);
    }

    /**
     * Lee una cadena de texto desde teclado
     * 
     * @param mensaje Mensaje a mostrar al usuario.
     * @return Cadena introducida por el usuario (sin espacios iniciales ni finales)
     */
    public String leerTexto(String mensaje) {
    	 String texto;
         do {
             System.out.print(mensaje + ": ");
             texto = sc.nextLine().trim();
             if (texto.isEmpty()) {
                 System.out.println("Error: el texto no puede estar vacío. Inténtalo de nuevo.");
             }
         } while (texto.isEmpty());
         return texto;
    }

    
    /**
     * Lee un número entero desde teclado.
     * 
     * @param mensaje Mensaje a mostrar al usuario.
     * @return Número entero introducido por el usuario
     */
    public int leerEntero(String mensaje) {
        while (true) {
            System.out.print(mensaje + ": ");
            try {
                return Integer.parseInt(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Error: introduce un número válido.");
            }
        }
    }

    /**
     * Lee un número decimal (double) desde teclado.
     *
     * @param mensaje Mensaje que se muestra al usuario antes de leer el dato.
     * @return Valor double introducido por el usuario.
     */
    public double leerDouble(String mensaje) {
        while (true) {
            System.out.print(mensaje + ": ");
            try {
                return Double.parseDouble(sc.nextLine().trim());
            } catch (NumberFormatException e) {
                System.out.println("Error: introduce un número decimal válido.");
            }
        }
    }

    /**
     * Cierra el Scanner asociado a esta instancia.
     * Debe llamarse al finalizar la ejecución del cliente
     * para liberar el recurso correctamente.
     */
    public void cerrar() {
        sc.close();
    }
    
    public String hash(String contraseña) {
    	String resultado = "";
    	try {
            MessageDigest md = MessageDigest.getInstance("SHA-256");
            byte[] hashBytes = md.digest(contraseña.getBytes());
            
            // Convertir a formato hexadecimal
            StringBuilder hexString = new StringBuilder();
            for (byte b : hashBytes) {
                String hex = Integer.toHexString(0xff & b);
                if (hex.length() == 1) hexString.append('0');
                hexString.append(hex);
            }
            
            resultado = hexString.toString();
            return resultado;
        } catch (NoSuchAlgorithmException e) {
            System.out.println("Algoritmo no soportado.");
        }
		return resultado;
    }
    
}
