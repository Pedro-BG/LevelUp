package config;
import java.io.InputStream;
import java.io.FileInputStream;
import java.util.Properties;
/**
 * 
 * Clase para leer los datos del fichero con la información del usuario
 * @author pedro Barrero
 * @since 22/05/2026
 * @version 1.0
 *
 */
public class LeerUsuario {

    private static final Properties properties = new Properties();

    static {
        try (InputStream input = new FileInputStream("config.properties")) {
            properties.load(input);
        } catch (Exception e) {
            System.err.println("[ERROR] No se encontró el archivo config.properties");
            e.printStackTrace();
        }
    }

    //BASE DE DATOS
    public static String getDBUser() { return properties.getProperty("db.user"); }

    public static String getDBPassword() { return properties.getProperty("db.password"); }

    public static String getDBUrl() { return properties.getProperty("db.url"); }

    //OPENROUTER
    public static String getApiKey() {
        return properties.getProperty("openrouter.apiKey");
    }

    public static String getModel() {
        return properties.getProperty("openrouter.model", "mistral");
    }

    public static String getApiUrl() {
        return properties.getProperty("openrouter.url", "https://openrouter.ai/api/v1/chat/completions");
    }
}