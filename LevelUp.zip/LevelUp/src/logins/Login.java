package logins;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

import Ulilidades.Utilidades;
import dao.ConexionBBDD;
import log.Log;

/**
 * 
 * Clase para los loggins
 * @author pedro Barrero
 * @since 22/05/2026
 * @version 1.0
 *
 */
public class Login {
	// Conexión a la base de datos
		ConexionBBDD conn = new ConexionBBDD();
		Connection conexion = conn.Conexion();
	// Utilidades
		Utilidades util = new Utilidades();
		
	/**
	 * Función para logear usuarios
	 * @param nombreUsuario
	 * @param contraseña
	 * @return si es valido o no
	 */
	public boolean loggin(String nombreUsuario, String contraseña) {
		try {
			Statement st = conexion.createStatement();
			ResultSet rs;
			//Hash a la contraseña
			String contraseñaC = util.hash(contraseña);
			// Consulta preparada
			String consulta = "SELECT * FROM Usuario";
			rs = st.executeQuery(consulta);
			// Obtener los campos
			while (rs.next()) {
				String usuario = rs.getString("nombre");
				String contraseñaU = rs.getString("contraseña");
				//Comprobar que esté registrado ese usuario
				if(usuario.equalsIgnoreCase(nombreUsuario) && contraseñaU.equals(contraseñaC)) {
					Log.registrar("Usuario ["+ usuario +"] loggeado correctamente");
					return true;
				}
			}
			
		} catch (Exception e) {
			System.out.println("================================");
			System.out.println("USUARIO O CONTRASEÑA INCORRECTOS");
			System.out.println("================================");
			Log.registrar("Error al loggear");
		}
		return false;
	}
	
	/**
	 * Función para logear administradores
	 * @param nombreUsuario
	 * @param contraseña
	 * @return
	 */
	public boolean admin(String nombreUsuario, String contraseña) {
		try {
		Statement st = conexion.createStatement();
		ResultSet rs;
		//Hash a la contraseña
		String contraseñaC = util.hash(contraseña);
		// Consulta preparada
		String consulta = "SELECT * FROM Usuario";
		rs = st.executeQuery(consulta);
		// Obtener los campos
		while (rs.next()) {
			String usuario = rs.getString("nombre");
			String contraseñaU = rs.getString("contraseña");
			boolean admin = rs.getBoolean("administrador");
			//Comprobar que esté registrado ese usuario
			if(usuario.equalsIgnoreCase(nombreUsuario) && contraseñaU.equals(contraseñaC) && admin == true ) {
				Log.registrar("Administrador ["+ usuario +"] activado");
				return true;
			}
			}
		} catch (Exception e) {
			System.out.println("================================");
			System.out.println("USUARIO O CONTRASEÑA INCORRECTOS");
			System.out.println("================================");
			Log.registrar("Error al loggear");
		}
		return false;
	}
}
