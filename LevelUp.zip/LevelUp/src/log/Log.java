package log;
import java.io.BufferedWriter;
import java.io.FileWriter;
import java.io.IOException;
import java.time.LocalDateTime;
public class Log {
	 private static final String RUTA_LOG = "logs/actividad.log";

	    public static void registrar(String mensaje) {

	        try {

	            // true = añadir al final sin borrar lo anterior
	            BufferedWriter bw = new BufferedWriter(new FileWriter(RUTA_LOG, true));

	            bw.write("[" + LocalDateTime.now() + "] " + mensaje);
	            bw.newLine();

	            bw.close();

	        } catch (IOException e) {

	            System.out.println("Error al escribir el log");
	            e.printStackTrace();
	        }
	    }
	}
