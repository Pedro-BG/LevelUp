package IA;
import java.io.OutputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import config.LeerUsuario;
/**
 * 
 * Clase para usar e integrar la IA de openRouter
 * @author pedro Barrero
 * @since 22/05/2026
 * @version 1.0
 *
 */
public class LlmService {

    public String enviarPrompt(String promptUsuario) {

        String apiKey = LeerUsuario.getApiKey();
        String model = LeerUsuario.getModel();
        String apiUrl = LeerUsuario.getApiUrl();

        try {
            // Escapar caracteres peligrosos
            String contenidoSeguro = promptUsuario
                    .replace("\\", "\\\\")
                    .replace("\"", "\\\"");

            // Construir JSON del prompt
            String json = """
            {
              "model": "%s",
              "messages": [
                {"role": "user", "content": "%s"}
              ]
            }
            """.formatted(model, contenidoSeguro);

            // Conexión HTTP
            HttpURLConnection connection = (HttpURLConnection) new URL(apiUrl).openConnection();
            connection.setRequestMethod("POST");
            connection.setRequestProperty("Authorization", "Bearer " + apiKey);
            connection.setRequestProperty("Content-Type", "application/json");
            connection.setDoOutput(true);

            // Enviar JSON
            try (OutputStream os = connection.getOutputStream()) {
                os.write(json.getBytes());
            }

            // Leer respuesta
            BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream()));
            StringBuilder response = new StringBuilder();
            String line;

            while ((line = br.readLine()) != null) {
                response.append(line);
            }

            // Parsear JSON
            JsonObject jsonResponse = JsonParser.parseString(response.toString()).getAsJsonObject();
            String texto = jsonResponse
                    .getAsJsonArray("choices")
                    .get(0).getAsJsonObject()
                    .getAsJsonObject("message")
                    .get("content").getAsString();

            return texto;

        } catch (Exception e) {
            return "[ERROR] No se pudo conectar con OpenRouter: " + e.getMessage();
        }
    }
}

