/* ══════════════════════════════════════════════════════
   Memoria del Proyecto — LevelUp Arcade
   main.js
══════════════════════════════════════════════════════ */

// ── MAPA DE PÁGINAS ──────────────────────────────────
const pages = {
  home:  'page-home',
  fase1: 'page-fase1',
  fase2: 'page-fase2',
  fase3: 'page-fase3',
  fase4: 'page-fase4',
  fase5: 'page-fase5',
  fase6: 'page-fase6',
  fase7: 'page-fase7',
  fase8: 'page-fase8',
  final: 'page-final'
};

const phaseMap = {
  home: '0', fase1: '1', fase2: '2', fase3: '3', fase4: '4',
  fase5: '5', fase6: '6', fase7: '7', fase8: '8', final: '9'
};

// ── NAVEGACIÓN ───────────────────────────────────────
function showPage(id) {
  document.querySelectorAll('.page').forEach(p => p.classList.remove('active'));
  document.getElementById(pages[id]).classList.add('active');
  document.querySelectorAll('.nav-item').forEach(n => n.classList.remove('active'));
  document.querySelector(`[data-phase="${phaseMap[id]}"]`).classList.add('active');
  window.scrollTo({ top: 0, behavior: 'smooth' });
  if (window.innerWidth <= 580) {
    document.getElementById('sidebar').classList.remove('open');
  }
}

function toggleNav() {
  document.getElementById('sidebar').classList.toggle('open');
}

// ── VÍDEO DE DEMOSTRACIÓN ────────────────────────────
// Para cambiar el vídeo, modifica el valor de VIDEO_SRC.
const VIDEO_SRC = 'VideoDeMuestra.mp4';

function setDemoVideo(src) {
  const videoSrc    = document.getElementById('demo-video-src');
  const video       = document.getElementById('demo-video');
  const placeholder = document.getElementById('video-placeholder');
  videoSrc.src = src;
  video.load();
  video.style.display       = 'block';
  placeholder.style.display = 'none';
}

// ── TARJETAS DE FASES (HOME) ─────────────────────────
const cardData = [
  { num: '01', title: 'Análisis del Sistema',    phase: 'fase1', color: 'var(--phase1)' },
  { num: '02', title: 'Diseño del Sistema',       phase: 'fase2', color: 'var(--phase2)' },
  { num: '03', title: 'Infraestructura y Entorno',phase: 'fase3', color: 'var(--phase3)' },
  { num: '04', title: 'Codificación',             phase: 'fase4', color: 'var(--phase4)' },
  { num: '05', title: 'Inteligencia Artificial',  phase: 'fase5', color: 'var(--phase5)' },
  { num: '06', title: 'Pruebas y Calidad',        phase: 'fase6', color: 'var(--phase6)' },
  { num: '07', title: 'Seguridad',                phase: 'fase7', color: 'var(--phase7)' },
  { num: '08', title: 'Despliegue',               phase: 'fase8', color: 'var(--phase8)' },
];

function buildHomeCards() {
  const container = document.getElementById('phase-cards');
  cardData.forEach(c => {
    const div = document.createElement('div');
    div.className = 'home-card';
    div.onclick = () => showPage(c.phase);
    div.innerHTML = `
      <div class="home-card-num">Fase ${c.num}</div>
      <div class="home-card-title">${c.title}</div>
      <div class="home-card-dot" style="background:${c.color}"></div>`;
    container.appendChild(div);
  });
}

// ── INIT ─────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  buildHomeCards();
  setDemoVideo(VIDEO_SRC);
});
